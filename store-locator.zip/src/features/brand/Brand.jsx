import React, { Component } from 'react';
import './brand.scss';

class Brand extends Component {
    render() {
        return (
            <div className='brand-component'>
                <div className='header'>Store locator</div>
            </div>
        );
    }
}

export default Brand;