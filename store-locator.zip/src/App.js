import Main from './layout/Main';

const App = () => {
  return (
    <div className='App'>
      <Main></Main>
    </div>
  );
};

export default App;